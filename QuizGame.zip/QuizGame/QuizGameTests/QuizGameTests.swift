//
//  QuizGameTests.swift
//  QuizGameTests
//
//  Created by Kshrugal Reddy Jangalapalli on 2/2/25.
//

import Testing
@testable import QuizGame

struct QuizGameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
